<template>
  <v-container>
    <v-row>
      <v-col v-for="device in devices" :key="device.id" cols="4">

        <v-card class="mx-auto" max-width="1400">
          <v-img
            class="align-end text-white"
            height="200"
            :src="device.photo"
            cover
          >
            <v-card-title>{{ device.name }}</v-card-title>
          </v-img>

          <v-card-subtitle class="pt-4">
            <div>{{ device.status }}</div>
          </v-card-subtitle>

          <v-card-text>
            <div>{{ device.description }}</div>
          </v-card-text>

          <v-card-actions>
            <router-link
              :to="{ name: 'device', params: { id: device.id } }"
              tag="b-btn"
            >
              detalhes
            </router-link>
          </v-card-actions>

        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>
  
<script>
import { useUserStore } from "@/stores/user";
import { useDeviceStore } from "@/stores/device"
import { RouterLink } from "vue-router";
export default {
  /*
  components: {
    device,
  },*/
  data() {
    return {
      deviceStore: useDeviceStore(),
      userStore: useUserStore()
    }
  },
  computed: {
    devices() {
      return this.deviceStore.getAllDevices
    }
  },

}
</script>